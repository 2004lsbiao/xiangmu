/* 
商城楼梯效果
1.左侧楼梯。
左侧楼梯一开始是隐藏的，接近楼层内容，左侧楼梯显示。
点击左侧楼梯，运动到对应右边的楼层。
拖动滚动条，右边的楼层发送位置变化，左侧楼梯对应的变化(添加背景)
2.右边的楼层。
3.楼梯和楼层是一一对应关系的。
4.回到顶部效果。 
*/
; !function () {
    //1.左侧楼梯一开始是隐藏的，接近楼层内容，左侧楼梯显示。
    let $louti = $('#loutinav');//楼梯1个
    let $loutili = $('#loutinav li');//楼梯内部的li
    let $louceng = $('#main .louti');//楼层9个


    let $top = $(window).scrollTop();//通过jq方法获取滚动条的top值。
    $top >= 700 ? $louti.show() : $louti.hide();

    $(window).on('scroll', function () {
        let $top = $(window).scrollTop();//通过jq方法获取滚动条的top值。
        $top >= 700 ? $louti.show() : $louti.hide();


        //4.拖动滚轮，左侧楼梯和右侧楼层位置对应的。(根据右侧的楼层位置给左侧楼梯添加active)
        $louceng.each(function (index, element) {
            //index:遍历元素的索引 element:当前元素对象(原生对象)
            let $lctop = $louceng.eq(index).offset().top + $(element).height() / 2;//获取每一个楼层的top值。
            $('title').html($top);
            //利用每一个楼层的top值和滚动条的距离进行比较，设置对应的楼梯。
            //楼层的top值是不变的。滚动条的top值是变化的。
            //如果楼层固定top值>滚动条top，添加active
            if ($lctop > $top) {
                $loutili.removeClass('active');//去掉所有的li上面的active
                $loutili.eq(index).addClass('active');//当前满足条件的添加。
                return false;//一旦满足，each结束。重新拖动滚轮，重新继续比较。
            }
        });


    });

    //2.点击左侧楼梯，运动到对应右边的楼层。楼层top值。
    $loutili.not('.last').on('click', function () {
        /* 
            链式调用(重点)：
            jquery都是链式操作的，基本上除了定义变量，很少出现等号。
            juqery链式调用的核心，就是方法执行完成后，方法内部依然返回了this(jquery对象)，即当前对象和当前对象相关的jquery对象。
            $(this).addClass('active').siblings('li').removeClass('active')
            例如上面的代码
            $(this)表达当前操作的元素对象
            .addClass('active')表示当前操作的元素对象添加类active，然后继续返回当前操作的对象。
            .siblings('li')表示获取当前操作对象的其他兄弟元素对象，然后返回当前元素对象的兄弟元素对象。
            .removeClass('active')表示当前操作对象的其他兄弟元素对象移除active，然后依然返回对象。
            总结：使用jquery下面的实例方法，前面一定是jq对象。
        */
        $(this).addClass('active').siblings('li').removeClass('active');
        /*  
        console.log($(this).index());//获取当前元素的索引。
        console.log($louceng.eq($(this).index()).offset().top);//对应楼层的top值 
        */
        let $top = $louceng.eq($(this).index()).offset().top;

        /* 
        原生读写滚动条的距离
        document.documentElelement.scrollTop = 100;
        document.body.scrollTop = 100;
        */
        $('html,body').animate({
            scrollTop: $top
        });
    });

    //3.回到顶部
    $('.last').on('click', function () {
        $('html,body').animate({
            scrollTop: 0
        });
    });
}();