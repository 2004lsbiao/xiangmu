/*
  1. 验证一下有没有登录过
    1-2. 从 cookie 里面获取 token 标识符
      + 如果是1, 表示登录过, 应该让 个人中心那一部分显示
      + 如果不是1, 表示没有登录过, 应该让 请登录那一部分显示
  2. 如果登陆过修改一下用户名位置的文本
    2-2. 从 cookie 里面获取当前登录用户的昵称
      + 显示在对应的文本位置


*/

// 1. 获取 token 标识符
let token = getcookie('token') - 0

// 1-1. 获取元素
//     属性选择器
//     需要是一个 p 标签, 并且有一个 name 属性, 值还得是 off
let off = document.querySelector('p[name=off]')
let on = document.querySelector('p[name=on]')

// 2-1. 获取元素
let nickname = document.querySelector('.nickname')

// 1-2. 判断有没有 token
if (token === 1) { // 表示已经登录了
  off.className = ''
  on.className = 'active'

  // 2-2. 获取到 cookie 中的昵称信息
  // let n = getcookie('nickname')
  // 设置到对应的文本位置
  nickname.innerText = getcookie('nickname')
} else { // 表示没有登录
  off.className = 'active'
  on.className = ''
}
