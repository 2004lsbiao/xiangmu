/*
  0. 登录验证
    + 如果你没有登录过, 直接跳转到登陆页面
    + 如果 cookie 中有 token 标识符旧表示登录过
    + 没有就是没有登陆过
  1. 获取表单， 取消默认事件
  2. 获取用户输入的旧密码和新密码
    + 多个用户用户名不能重复， 但是密码是可以一样的
    + 把密码改成 123456， 修改谁的密码？
    + 应该在登录成功的时候， 除了昵称在多获取一个数据叫做 id => id 是一个数据的唯一标识符
    + 现在旧有了用户 ID, 我要修改的时候, 就是修改对应 ID 的密码
  3. 发送请求
    + 把新密码和旧密码还有用户id 都要携带过去
  4. 根据结果操作
    + 如果结果是修改失败, 我就提示一下错误
    + 如果结果是修改成功
      + 跳回登录页
      + 取消你的登录状态
        + 把 现在 存储的 cookie 删除了
*/

// 0. 登录验证
let token = getcookie('token') - 0

if (token !== 1) {
  // 表示没有登陆过
  // 直接跳转回登录页面
  window.location.href = './login.html'
}

// 1. 获取表单
let form = document.querySelector('form')

// 2. 获取元素
let oldInp = document.querySelector('.oldInp')
let newInp = document.querySelector('.newInp')

// 4. 获取元素
let errText = document.querySelector('form span')


// 1-2. 绑定事件
form.addEventListener('submit', e => {
  // 1-3. 取消默认事件
  e = e || window.event
  e.preventDefault()

  // 2-2. 获取用户输入的内容
  let oldPass = oldInp.value
  let newPass = newInp.value
  // 还要获取一个要修改的用户 ID
  // 假设你的 id 是 1, 就是要修改 id 为 1 的那一条数据的密码
  let userId = getcookie('userId')

  // 3. 发送请求
  // 提前准备好一个字符串
  let dataStr = `oldPass=${ oldPass }&newPass=${ newPass }&userId=${ userId }`
  // 使用 ajax 方法发送请求
  ajax({
    url: '../server/rpass.php',
    type: 'POST',
    data: dataStr,
    dataType: 'json',
    success: function (res) {
      // res => 后端返回的数据
      console.log(res)

      // 4. 根据结果做对应的操作
      if (res.code === 0) {
        errText.className = 'active'
      } else {
        // 4-2. 把已经存储的 cookie 删除掉
        setcookie('userId', '', -10)
        setcookie('token', '', -10)
        setcookie('nickname', '', -10)

        window.location.href = './login.html'
      }
    }
  })
})
