/**
 * 设置 cookie 的方法
 * @param {STRING} key 要设置的 cookie 的 key
 * @param {ANY} value 要设置的 cookie 的 value
 * @param {NUMBER} expires 要设置的 cookie 的过期时间, 单位是 s
 */
function setcookie(key, value, expires) {
  // key => 'a'
  // value => 100
  // 'a' + '=' + 100 => 'a=100'

  if (expires === undefined) {
    // 没传递第三个参数
    document.cookie = key + '=' + value
  } else {
    // 传递了第三个参数, 加上过期时间
    let time = new Date()
    let n = time.getTime() - 1000 * 60 * 60 * 8 + 1000 * expires
    time.setTime(n)
    // document.cookie = key + '=' + value + ';expires=' + time
    document.cookie = `${ key }=${ value };expires=${ time }`
  }
}

/**
 * 查询 cookie 的方法
 * @param {STRING} key 你要查询的 cookie 的 key
 * @return {STRING} 你要查询的 cookie 的 value
 */
function getcookie(key) {
  // key => 'a'

  // 0 提前准备一个变量
  let str = ''

  // 1. 获取到所有的 cookie
  let tmp = document.cookie.split('; ')

  // 2. 遍历 tmp 数组
  tmp.forEach(item => {
    // console.log(item.split('='))

    // 3. 判断, 如果 [0] 和 传递进来的 key 一摸一样
    //    [1] 就是你要的值
    let t = item.split('=')

    if (t[0] === key) str = t[1]
  })

  // 4. 循环结束
  //    如果一个对应上的都没有 str === ''
  //    只要有对应上的, str === 对应的值
  //    把 str 返回
  return str
}
