
  function djs() {
    var futureTime = new Date('2020,10,1 00:00:00');
    var currentTime = new Date();

    var time = parseInt((futureTime - currentTime) / 1000);

    var day = parseInt(time / (24 * 60 * 60));
    var hour = parseInt(time % (60 * 60 * 24) / (60 * 60));
    var min = parseInt(time % (60 * 60) / 60);
    var section = time % 60;
    return "距国庆节还有" + day + '天' +'<br>'+ hour+'小时'+min +'分钟'+section +'秒';
}
CountZero1.innerHTML = djs();
setInterval(function(){
    CountZero1.innerHTML = djs();
},1000)