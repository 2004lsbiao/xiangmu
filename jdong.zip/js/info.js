/*
  0. 登录验证
    + 没有登录过的时候跳转回登录页面
  1. 获取到当前用户的邮箱和个人介绍信息
    + 获取回来以后填充到对应的表单里面
    + 获取谁的个人信息, 现在登录的这个人
    + userId 旧表示当前登录的这个人
  2. 拿到个人信息以后
    + 填充到表单里面
  3. 获取表单, 取消默认事件
  4. 再次获取用户输入的内容
    + 不需要非空验证
  5. 发送请求, 修改个人信息
    + 这里发送请求的时候还是要携带一个用户 id
    + 需要知道修改哪一个用户的个人信息和邮箱

*/

// 0. 登录验证
let token = getcookie('token') - 0
if (token !== 1) {
  window.location.href = './login.html'
}

// 1. 通过 userId 获取这个用户的个人信息
let userId = getcookie('userId') - 0

// 2. 获取元素
let emailInp = document.querySelector('.email')
let infoInp = document.querySelector('.info')

// 3. 获取表单
let form = document.querySelector('form')

// 1-2. 发送请求拿到这个用户的个人信息
//      直接使用 ajax 方法
ajax({
  url: '../server/getInfo.php',
  data: `userId=${ userId }`,
  dataType: 'json',
  success: function (res) {
    // res => 后端返回的个人信息
    // console.log(res)

    // 2-2. 把结果填充进去
    emailInp.value = res.email
    infoInp.value = res.info
  }
})

// 3-2. 绑定事件
form.addEventListener('submit', e => {
  // 3-3. 取消默认事件
  e = e || window.event
  e.preventDefault()

  // 4-2. 获取用户输入的内容
  let email = emailInp.value
  let info = infoInp.value

  // 4-3. 表单验证
  //      验证一个邮箱格式
  //      验证一个个人信息文本数量

  // 5. 发送请求进行修改
  // 提前准备一个字符串
  let dataStr = `email=${ email }&info=${ info }&userId=${ userId }`;
  ajax({
    url: '../server/setInfo.php',
    type: 'POST',
    data: dataStr,
    dataType: 'json',
    success: function (res) {
      // res => 后端返回的数据
      // console.log(res)

      // 根据修改成功的信息告诉用户一下
      if (res.code === 1) {
        let r = confirm('修改个人信息成功, 点击确定跳转回首页, 点击取消留在本页面')
        if (r) window.location.href = './index.html'
      }
    }
  })
})
