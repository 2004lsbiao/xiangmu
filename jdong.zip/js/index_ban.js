/*
  渐隐渐显轮播图

    1. 根据图片盒子里面图片的数量设置焦点盒子里面的焦点
      + 需要获取 图片盒子
      + 需要获取 焦点盒子
      + 准备一个方法, 能根据 图片盒子 里面图片的数量 设置 焦点盒子里面的焦点
    2. 切换一张
      + 让所有的都消失
      + 让下一张显示
      + 准备一个变量, 记录第几张
    3. 自动轮播
      + 每间隔固定时间(2s) 切换一张
      + 定时器 setInterval()
    4. 移入移出
      + 移入 banner 盒子的时候, 定时器停止
      + 移出 banner 盒子的时候, 定时器开启
    5. 点击左右按钮切换
      + 获取左边按钮 => 上一张 => this.index--
      + 获取右边按钮 => 下一张 => this.index++
    6. 点击焦点切换
      + 点击的是那一个焦点
      + 就让所有的都没有类名
      + 让你点击焦点对应索引的那一个有类名
      + 绑定给 pointBox 里面的每一个 li
*/

class Banner {
  // 构造函数
  constructor (id) {
    this.ele = document.querySelector(id)
    this.imgBox = this.ele.querySelector('.imgBox')
    this.pointBox = this.ele.querySelector('.pointBox')
    this.leftBtn = this.ele.querySelector('.left')
    this.rightBtn = this.ele.querySelector('.right')
    this.index = 0
    this.timerId = 0
    this.init()
  }
  // 调用函数
  init () {
    this.setPoint()
    this.autoPlay()
    this.overOut()
    this.leftRightChange()
    this.pointsEvent()
  }
  // 设置焦点
  setPoint () {
    let pointNum = this.imgBox.children.length
    let frg = document.createDocumentFragment()
    for (let i = 0; i < pointNum; i++) {
      let li = document.createElement('li')
      if (i === 0) li.className = 'active'
      frg.appendChild(li)
    }
    this.pointBox.appendChild(frg)
  }
  // 2. 切换一张
  changeOne () {
    if (this.index >= this.imgBox.children.length) { this.index = 0 }
    if (this.index < 0) { this.index = this.imgBox.children.length - 1 }
    for (let i = 0; i < this.imgBox.children.length; i++) {
      this.imgBox.children[i].className = ''
      this.pointBox.children[i].className = ''
    }
    this.imgBox.children[this.index].className = 'active'
    this.pointBox.children[this.index].className = 'active'
  }
  // 自动轮播
  autoPlay () {
    this.timerId = setInterval(() => {
      this.index++
      this.changeOne()
    }, 2000)
  }
  // 聚焦失焦
  overOut () {
    this.ele.onmouseover = () => clearInterval(this.timerId)
    this.ele.onmouseout = () => this.autoPlay()
  }
  // 左右切换
  leftRightChange () {
    this.leftBtn.onclick = () => {
      this.index--
      this.changeOne()
    }
    this.rightBtn.onclick = () => {
      this.index++
      this.changeOne()
    }
  }
  // 点击焦点
  pointsEvent() {
    let _this = this
    for (let i = 0; i < this.pointBox.children.length; i++) {
      this.pointBox.children[i].setAttribute('point_index', i)
      this.pointBox.children[i].addEventListener('click', function () {
        console.log(arguments)
        let point_index = this.getAttribute('point_index') - 0
        _this.index = point_index
        _this.changeOne()
      })
    }
  }
}
let b1 = new Banner('#box')
new Banner('.shoufa0')
new Banner('.shoufa1')
new Banner('.shoufa2')


/*
  页面打开
    this.index = 0
  2s 以后
    this.index++ => this.index === 1
    this.changeOne() => 让所有的 imgBox 里面的 li 都没有类名, 让 imgBox[1] 有 active
*/
