<?php

  # base.php
  # 写一些连接数据库的信息

  # 1. 连接数据库
  $conn = mysql_connect('localhost', 'root', 'root');

  # 2. 确定操作哪一个库
  mysql_select_db('test');

?>
