<?php

  # 导入 base.php
  include "./base.php";

  # 1. 接受前端发送过来的 用户名 和 密码
  $username = $_POST['username'];
  $password = $_POST['password'];

  # 2. 准备一个 sql 语句
  #    表名 和 字段名 用 反引号(``) 包裹
  #    文本用 单引号('')
  $sql = "SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'";

  # 3. 执行 sql 语句
  $res = mysql_query($sql);

  # 4. 解析结果
  #    因为执行的 查询 的 sql 语句, 所以需要解析结果
  $row = mysql_fetch_assoc($res);

  /*
    $row => 是解析的从数据库里面查询出来的内容
    如果能查询出内容
    $row = array(
      "username" => "admin",
      "password" => "123456",
      "nickname" => "管理员"
    );
    $row['nickname'] => "管理员"
  */

  # 5. 根据解析结果来决定给前端返回的数据
  if ($row) { // 表示查询到数据了 => 登录成功
    # 多给你一个信息, 就是昵称信息
    $arr = array(
      "message" => "登录成功",
      "code" => 1,
      "nickname" => $row['nickname'],
      "userId" => $row['id']
    );
  } else { // 没有查询到数据 => 登录失败
    $arr = array( "message" => "登录失败", "code" => 0 );
  }

  # 6. 把我准备好的数据返回给前端
  #    因为我们的时一个关联型数组, 前端不认识, 所以要转换成 json 格式的数据传递
  echo json_encode($arr);

?>
