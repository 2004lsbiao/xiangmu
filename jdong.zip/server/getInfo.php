<?php

  # 1. 导入 base.php 文件
  include "./base.php";

  # 2. 接受前端传递来的 id 信息
  $id = $_GET['userId'];

  # 3. 通过 ID 获取用户的信息, 返回给前端
  $sql = "SELECT * FROM `users` WHERE `id`=$id";
  $res = mysql_query($sql);
  $row = mysql_fetch_assoc($res);

  /*
    $row 里面都包含哪些信息
      + 用户名
      + 密码
      + 昵称
      + 邮箱
      + 个人介绍
  */

  # 选择一部分信息给前端
  $arr = array(
    "message" => "获取个人信息成功",
    "email" => $row['email'],
    "info" => $row['info']
  );

  # 返回给前端
  echo json_encode($arr);


?>
